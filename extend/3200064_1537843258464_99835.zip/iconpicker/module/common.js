layui.config({
    base: './module/'
}).extend({
    iconPicker: 'iconPicker/iconPicker'
});